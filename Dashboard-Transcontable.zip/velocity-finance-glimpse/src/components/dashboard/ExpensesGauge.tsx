import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Label } from 'recharts';
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface ExpensesGaugeProps {
  currentExpenses: number;
  averageExpenses: number;
}

const ExpensesGauge: React.FC<ExpensesGaugeProps> = ({ 
  currentExpenses, 
  averageExpenses 
}) => {
  // Calcular porcentaje de gastos comparado con el promedio
  const porcentaje = Math.round((currentExpenses / averageExpenses) * 100);
  
  // Determinar color basado en la proporción
  const color = porcentaje > 100 ? '#f87171' : '#60a5fa'; // rojo si está sobre el promedio, azul si es normal
  
  // Para el medidor, queremos mostrar cuánto del promedio se usa
  // pero limitado al 150% por propósitos visuales
  const valorMedidor = Math.min(porcentaje, 150);
  
  // Calcular la posición para la marca del 100% (promedio)
  // 100% debería estar en 2/3 del medidor completo (ya que el máximo es 150%)
  const marcaPromedio = 100 / 150;

  // Usar segmentos para crear el medidor con marcadores
  // Segmento 1: De 0% a justo antes del promedio (si el actual es mayor que el promedio)
  // Segmento 2: La marca del promedio como un pequeño segmento (raya)
  // Segmento 3: De justo después del promedio al valor actual (si el actual es mayor que el promedio)
  // Segmento 4: Restante hasta el 150%
  
  let datos = [];
  const anchoRaya = 3 / 150; // Ancho de la raya como porcentaje del medidor total
  
  if (valorMedidor <= marcaPromedio * 150) {
    // Caso: Valor actual está por debajo o igual al promedio
    datos = [
      { nombre: 'Actual', valor: valorMedidor, fill: color },
      { nombre: 'MarcaPromedio', valor: anchoRaya * 150, fill: '#2563eb' }, // Raya azul para el promedio
      { nombre: 'Restante', valor: 150 - valorMedidor - (anchoRaya * 150), fill: '#e5e7eb' }
    ];
  } else {
    // Caso: Valor actual está por encima del promedio
    datos = [
      { nombre: 'AntesPromedio', valor: marcaPromedio * 150 - (anchoRaya * 150/2), fill: '#60a5fa' },
      { nombre: 'MarcaPromedio', valor: anchoRaya * 150, fill: '#2563eb' }, // Raya azul para el promedio
      { nombre: 'DespuesPromedio', valor: valorMedidor - (marcaPromedio * 150 + (anchoRaya * 150/2)), fill: '#f87171' },
      { nombre: 'Restante', valor: 150 - valorMedidor, fill: '#e5e7eb' }
    ];
  }

  // Marcador máximo como una raya
  const datosMax = [
    { nombre: 'AntesMax', valor: 150 - (anchoRaya * 150), fill: 'transparent' },
    { nombre: 'MarcaMax', valor: anchoRaya * 150, fill: '#ef4444' } // Raya roja para el máximo
  ];

  return (
    <div className="flex flex-col h-full">
      <h2 className="text-xl font-bold mb-2">Gastos</h2>
      <div className="flex flex-col items-center justify-center flex-grow">
        <div className="w-full h-[400px] relative"> {/* Altura duplicada de 200px a 400px */}
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              {/* Medidor principal con segmentos */}
              <Pie
                data={datos}
                cx="50%"
                cy="50%"
                startAngle={180}
                endAngle={0}
                innerRadius="60%"
                outerRadius="90%"
                paddingAngle={0}
                dataKey="valor"
                strokeWidth={0}
              >
                {datos.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Pie>
              
              {/* Superposición del marcador máximo */}
              <Pie
                data={datosMax}
                cx="50%"
                cy="50%"
                startAngle={180}
                endAngle={0}
                innerRadius="60%"
                outerRadius="90%"
                paddingAngle={0}
                dataKey="valor"
                strokeWidth={0}
              >
                {datosMax.map((entry, index) => (
                  <Cell key={`max-cell-${index}`} fill={entry.fill} />
                ))}
              </Pie>
              
              {/* Etiquetas y tooltip */}
              <Pie
                data={[{ nombre: 'Etiqueta', valor: 100 }]}
                cx="50%"
                cy="50%"
                startAngle={180}
                endAngle={0}
                innerRadius="60%"
                outerRadius="90%"
                paddingAngle={0}
                dataKey="valor"
                strokeWidth={0}
                fill="transparent"
              >
                <Label
                  content={(props) => {
                    if (!props.viewBox) return null;
                    const { cx = 0, cy = 0 } = props.viewBox as any;
                    return (
                      <>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <g>
                                <text 
                                  x={cx} 
                                  y={cy} 
                                  textAnchor="middle" 
                                  dominantBaseline="middle"
                                  className="font-bold text-4xl fill-current"
                                >
                                  ${currentExpenses.toLocaleString()}
                                </text>
                                <text 
                                  x={cx} 
                                  y={cy + 50}
                                  textAnchor="middle" 
                                  dominantBaseline="middle"
                                  className="text-xl fill-gray-500"
                                >
                                  Gastos Actuales
                                </text>
                              </g>
                            </TooltipTrigger>
                            <TooltipContent className="bg-white p-3 shadow-lg border rounded-md">
                              <div className="text-center">
                                <p className="font-bold text-lg">{porcentaje}%</p>
                                <p className="text-xs text-gray-500">del promedio</p>
                              </div>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </>
                    );
                  }}
                />
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          
          {/* Etiquetas para los marcadores movidas a la derecha */}
          <div 
            className="absolute pointer-events-none" 
            style={{
              left: `calc(50% + ${Math.cos((1 - marcaPromedio) * Math.PI) * 180}px)`, /* Duplicado de 90px a 180px */
              top: `calc(50% - ${Math.sin((1 - marcaPromedio) * Math.PI) * 180}px)`, /* Duplicado de 90px a 180px */
              transform: 'translateX(10px)', /* Mover etiqueta a la derecha del marcador */
            }}
          >
            <div className="text-sm font-medium text-gray-700">Promedio</div> {/* Aumentado de xs a sm */}
          </div>
          
          <div 
            className="absolute pointer-events-none" 
            style={{
              left: `calc(50% + ${Math.cos(0) * 180}px)`, /* Duplicado de 90px a 180px */
              top: `calc(50% - ${Math.sin(0) * 180}px)`, /* Duplicado de 90px a 180px */
              transform: 'translateX(10px)', /* Mover etiqueta a la derecha del marcador */
            }}
          >
            <div className="text-sm font-medium text-gray-700">Máx</div> {/* Eliminado (150%) */}
          </div>
        </div>
        <div className="mt-2 w-full"> {/* Reducido mt de 6 a 2 */}
          <div className="flex justify-between items-center text-base"> {/* Aumentado de sm a base */}
            <div className="flex items-center">
              <span className="w-4 h-4 rounded-full bg-dashboard-info mr-2"></span>
              <span>Promedio: ${averageExpenses.toLocaleString()}</span>
            </div>
            <div className="flex items-center">
              <span className={`w-4 h-4 rounded-full ${porcentaje > 100 ? 'bg-dashboard-danger' : 'bg-dashboard-info'} mr-2`}></span>
              <span>Actual: ${currentExpenses.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExpensesGauge;
