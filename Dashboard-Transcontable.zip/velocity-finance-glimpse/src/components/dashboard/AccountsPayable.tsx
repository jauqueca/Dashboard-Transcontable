import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface Factura {
  id: number;
  proveedor: string;
  monto: number;
  fechaVencimiento: string;
  estado: 'vencido' | 'proximo'; // vencido es rojo, proximo es naranja
  diasRestantes: number;
}

interface CuentasPorPagarProps {
  invoices: Factura[];
}

const AccountsPayable: React.FC<CuentasPorPagarProps> = ({ invoices }) => {
  // Ordenar facturas: vencidas primero (ordenadas por más vencidas), luego próximas (ordenadas por fecha más cercana)
  const facturasOrdenadas = [...invoices].sort((a, b) => {
    // Primero ordenar por estado (vencidas antes que próximas)
    if (a.estado === 'vencido' && b.estado !== 'vencido') return -1;
    if (a.estado !== 'vencido' && b.estado === 'vencido') return 1;
    
    // Luego ordenar por diasRestantes
    // Para vencidas: más negativo primero (más días de retraso)
    // Para próximas: menos positivo primero (fecha más cercana)
    return a.diasRestantes - b.diasRestantes;
  });

  return (
    <div className="flex flex-col h-full">
      <h2 className="text-xl font-bold mb-2">Cuentas por Pagar</h2>
      <div className="bg-white rounded-lg shadow-dashboard p-4 flex-grow overflow-hidden">
        <div className="overflow-auto h-full">
          {facturasOrdenadas.length === 0 ? (
            <div className="h-full flex items-center justify-center text-gray-400">
              No hay facturas pendientes
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Proveedor</TableHead>
                  <TableHead className="text-right">Monto</TableHead>
                  <TableHead className="text-right">Vencimiento</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {facturasOrdenadas.map((factura) => (
                  <TableRow key={factura.id}>
                    <TableCell>
                      <div className="flex items-center">
                        <span 
                          className={`w-3 h-3 rounded-full mr-2 ${
                            factura.estado === 'vencido' ? 'bg-dashboard-danger' : 'bg-dashboard-orange'
                          }`}
                        ></span>
                        <span>{factura.proveedor}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">${factura.monto.toLocaleString()}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex flex-col items-end">
                        <span>{factura.fechaVencimiento}</span>
                        <span className={`text-xs ${
                          factura.estado === 'vencido' ? 'text-dashboard-danger' : 'text-dashboard-orange'
                        }`}>
                          {factura.estado === 'vencido' 
                            ? `${Math.abs(factura.diasRestantes)} días de retraso` 
                            : `${factura.diasRestantes} días restantes`}
                        </span>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </div>
      </div>
    </div>
  );
};

export default AccountsPayable;
