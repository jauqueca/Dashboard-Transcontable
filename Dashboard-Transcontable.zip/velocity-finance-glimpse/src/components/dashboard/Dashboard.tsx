import React from 'react';
import SalesGauge from './SalesGauge';
import ExpensesGauge from './ExpensesGauge';
import CriticalInventory from './CriticalInventory';
import AccountsPayable from './AccountsPayable';
import DailySales from './DailySales';

// Definir interfaz para datos de ventas diarias
interface VentaDiaria {
  dia: number;
  ventas: number;
  tendencia: number;
}

// Definir el tipo completo de datosMock con todas las propiedades
interface DatosMock {
  ventas: {
    ventasActuales: number;
    ventasObjetivo: number;
    puntoEquilibrio: number;
  };
  gastos: {
    gastosActuales: number;
    gastosPromedio: number;
  };
  inventarioCritico: Array<{
    id: number;
    nombre: string;
    stockActual: number;
    stockMinimo: number;
    estado: 'critico' | 'alerta';
  }>;
  cuentasPorPagar: Array<{
    id: number;
    proveedor: string;
    monto: number;
    fechaVencimiento: string;
    estado: 'vencido' | 'proximo';
    diasRestantes: number;
  }>;
  ventasDiarias: VentaDiaria[];
}

// Datos de muestra para demostración
const datosMock: DatosMock = {
  ventas: {
    ventasActuales: 85000,
    ventasObjetivo: 100000,
    puntoEquilibrio: 65000
  },
  gastos: {
    gastosActuales: 62000,
    gastosPromedio: 60000
  },
  inventarioCritico: [
    { id: 1, nombre: 'Aceite de motor', stockActual: 5, stockMinimo: 10, estado: 'critico' as const },
    { id: 2, nombre: 'Filtros de aire', stockActual: 8, stockMinimo: 15, estado: 'critico' as const },
    { id: 3, nombre: 'Neumáticos 245/70R16', stockActual: 4, stockMinimo: 6, estado: 'alerta' as const },
    { id: 4, nombre: 'Baterías 12V', stockActual: 3, stockMinimo: 5, estado: 'alerta' as const },
    { id: 5, nombre: 'Líquido de frenos', stockActual: 7, stockMinimo: 12, estado: 'critico' as const }
  ],
  cuentasPorPagar: [
    { id: 1, proveedor: 'Repuestos Nacionales', monto: 12500, fechaVencimiento: '2025-04-28', estado: 'vencido' as const, diasRestantes: -8 },
    { id: 2, proveedor: 'Distribuidora de Llantas', monto: 8750, fechaVencimiento: '2025-05-12', estado: 'proximo' as const, diasRestantes: 6 },
    { id: 3, proveedor: 'Lubricantes Industriales', monto: 3200, fechaVencimiento: '2025-04-30', estado: 'vencido' as const, diasRestantes: -6 },
    { id: 4, proveedor: 'Autopartes Express', monto: 5400, fechaVencimiento: '2025-05-15', estado: 'proximo' as const, diasRestantes: 9 },
    { id: 5, proveedor: 'Servicios Logísticos', monto: 7800, fechaVencimiento: '2025-05-10', estado: 'proximo' as const, diasRestantes: 4 }
  ],
  ventasDiarias: [] // Inicializar con array vacío, será poblado por generarDatosVentasDiarias
};

// Generar datos de ventas diarias por separado para evitar referenciar el array mientras se construye
const generarDatosVentasDiarias = (): VentaDiaria[] => {
  const arrayVentasDiarias: VentaDiaria[] = [];
  
  for (let i = 0; i < 30; i++) {
    const dia = i + 1;
    const esFinDeSemana = dia % 7 === 0 || dia % 7 === 6;
    const ventaBase = Math.floor(Math.random() * 3000) + 2000;
    const ventas = esFinDeSemana ? ventaBase * 0.6 : ventaBase;
    
    // Calcular tendencia usando un enfoque más simple que no hace referencia al array en construcción
    let tendencia = ventas;
    if (i > 2) {
      // Obtener los últimos 3 elementos que ya hemos añadido
      const prev1 = arrayVentasDiarias[i-1].ventas;
      const prev2 = arrayVentasDiarias[i-2].ventas;
      tendencia = Math.round((ventas + prev1 + prev2) / 3);
    }
    
    arrayVentasDiarias.push({
      dia,
      ventas,
      tendencia
    });
  }
  
  return arrayVentasDiarias;
};

// Añadir las ventas diarias a los datos de muestra
datosMock.ventasDiarias = generarDatosVentasDiarias();

const Dashboard: React.FC = () => {
  return (
    <div className="w-full max-w-[1920px] mx-auto p-6 bg-gray-50">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        <div className="bg-white rounded-lg shadow-dashboard p-6 h-[500px]"> {/* Altura aumentada de 300px a 500px */}
          <SalesGauge 
            currentSales={datosMock.ventas.ventasActuales}
            targetSales={datosMock.ventas.ventasObjetivo}
            breakEvenPoint={datosMock.ventas.puntoEquilibrio}
          />
        </div>
        <div className="bg-white rounded-lg shadow-dashboard p-6 h-[500px]"> {/* Altura aumentada de 300px a 500px */}
          <ExpensesGauge 
            currentExpenses={datosMock.gastos.gastosActuales}
            averageExpenses={datosMock.gastos.gastosPromedio}
          />
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="h-[360px]">
          <CriticalInventory items={datosMock.inventarioCritico} />
        </div>
        <div className="h-[360px]">
          <AccountsPayable invoices={datosMock.cuentasPorPagar} />
        </div>
        <div className="h-[360px]">
          <DailySales data={datosMock.ventasDiarias} />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
