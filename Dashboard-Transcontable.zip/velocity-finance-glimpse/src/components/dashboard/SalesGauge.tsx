import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Label } from 'recharts';
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface SalesGaugeProps {
  currentSales: number;
  targetSales: number;
  breakEvenPoint: number;
}

const SalesGauge: React.FC<SalesGaugeProps> = ({ 
  currentSales, 
  targetSales, 
  breakEvenPoint 
}) => {
  // Calcular porcentaje del objetivo alcanzado
  const porcentaje = Math.min(Math.round((currentSales / targetSales) * 100), 100);
  
  // Calcular porcentaje de punto de equilibrio relativo al objetivo
  const porcentajeEquilibrio = Math.min(Math.round((breakEvenPoint / targetSales) * 100), 100);
  
  // Ancho de las rayas como porcentaje del medidor
  const anchoRaya = 3; 
  
  // Determinar color basado en el rendimiento
  let colorBajoEquilibrio = '#f87171'; // Rojo - por debajo del punto de equilibrio
  let colorSobreEquilibrio = '#facc15'; // Amarillo - por encima del punto de equilibrio pero por debajo del objetivo
  let colorObjetivoAlcanzado = '#4ade80'; // Verde - en o por encima del objetivo
  
  // Crear segmentos para representar el medidor con marcadores integrados
  let datos = [];
  
  if (porcentaje <= porcentajeEquilibrio - anchoRaya/2) {
    // Caso 1: Valor actual está por debajo del punto de equilibrio
    datos = [
      { nombre: 'Actual', valor: porcentaje, fill: colorBajoEquilibrio },
      { nombre: 'MarcaEquilibrio', valor: anchoRaya, fill: '#ef4444' }, // Raya roja para punto de equilibrio
      { nombre: 'DespuesEquilibrio', valor: (porcentajeEquilibrio + anchoRaya/2) - (porcentaje + anchoRaya), fill: '#e5e7eb' },
      { nombre: 'MarcaObjetivo', valor: anchoRaya, fill: '#22c55e' }, // Raya verde para objetivo
      { nombre: 'Restante', valor: 100 - (porcentajeEquilibrio + anchoRaya/2) - anchoRaya, fill: '#e5e7eb' }
    ];
  } else if (porcentaje >= porcentajeEquilibrio + anchoRaya/2 && porcentaje < 100 - anchoRaya/2) {
    // Caso 2: Valor actual está por encima del punto de equilibrio pero por debajo del objetivo
    datos = [
      { nombre: 'AntesEquilibrio', valor: porcentajeEquilibrio - anchoRaya/2, fill: colorBajoEquilibrio },
      { nombre: 'MarcaEquilibrio', valor: anchoRaya, fill: '#ef4444' }, // Raya roja para punto de equilibrio
      { nombre: 'Actual', valor: porcentaje - (porcentajeEquilibrio + anchoRaya/2), fill: colorSobreEquilibrio },
      { nombre: 'MarcaObjetivo', valor: anchoRaya, fill: '#22c55e' }, // Raya verde para objetivo
      { nombre: 'Restante', valor: 100 - porcentaje - anchoRaya/2, fill: '#e5e7eb' }
    ];
  } else if (porcentaje >= 100 - anchoRaya/2) {
    // Caso 3: Valor actual está en o por encima del objetivo
    datos = [
      { nombre: 'AntesEquilibrio', valor: porcentajeEquilibrio - anchoRaya/2, fill: colorBajoEquilibrio },
      { nombre: 'MarcaEquilibrio', valor: anchoRaya, fill: '#ef4444' }, // Raya roja para punto de equilibrio
      { nombre: 'Medio', valor: (100 - anchoRaya) - (porcentajeEquilibrio + anchoRaya/2), fill: colorSobreEquilibrio },
      { nombre: 'Objetivo', valor: anchoRaya, fill: '#22c55e' }, // Raya verde para objetivo
      { nombre: 'EnObjetivo', valor: 0, fill: colorObjetivoAlcanzado }, // Esto será 0 ya que limitamos al 100%
    ];
  } else {
    // Caso 4: Valor actual está exactamente en el punto de equilibrio (dentro de la raya)
    datos = [
      { nombre: 'AntesEquilibrio', valor: porcentajeEquilibrio - anchoRaya/2, fill: colorBajoEquilibrio },
      { nombre: 'MarcaEquilibrio', valor: anchoRaya, fill: '#ef4444' }, // Raya roja para punto de equilibrio
      { nombre: 'DespuesEquilibrio', valor: 100 - (porcentajeEquilibrio + anchoRaya/2) - anchoRaya, fill: '#e5e7eb' },
      { nombre: 'MarcaObjetivo', valor: anchoRaya, fill: '#22c55e' }, // Raya verde para objetivo
      { nombre: 'Restante', valor: 0, fill: '#e5e7eb' }
    ];
  }

  return (
    <div className="flex flex-col h-full">
      <h2 className="text-xl font-bold mb-2">Ventas</h2>
      <div className="flex flex-col items-center justify-center flex-grow">
        <div className="w-full h-[400px] relative">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={datos}
                cx="50%"
                cy="50%"
                startAngle={180}
                endAngle={0}
                innerRadius="60%"
                outerRadius="90%"
                paddingAngle={0}
                dataKey="valor"
                strokeWidth={0}
              >
                {datos.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
                <Label
                  content={(props) => {
                    if (!props.viewBox) return null;
                    const { cx = 0, cy = 0 } = props.viewBox as any;
                    return (
                      <>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <g>
                                <text 
                                  x={cx} 
                                  y={cy} 
                                  textAnchor="middle" 
                                  dominantBaseline="middle"
                                  className="font-bold text-4xl fill-current"
                                >
                                  ${currentSales.toLocaleString()}
                                </text>
                                <text 
                                  x={cx} 
                                  y={cy + 50}
                                  textAnchor="middle" 
                                  dominantBaseline="middle"
                                  className="text-xl fill-gray-500"
                                >
                                  Ventas Actuales
                                </text>
                              </g>
                            </TooltipTrigger>
                            <TooltipContent className="bg-white p-3 shadow-lg border rounded-md">
                              <div className="text-center">
                                <p className="font-bold text-lg">{porcentaje}%</p>
                                <p className="text-xs text-gray-500">del objetivo</p>
                              </div>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </>
                    );
                  }}
                />
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          
          {/* Etiquetas para los marcadores movidas al lado derecho */}
          <div 
            className="absolute pointer-events-none" 
            style={{
              left: `calc(50% + ${Math.cos((1 - porcentajeEquilibrio/100) * Math.PI) * 180}px)`,
              top: `calc(50% - ${Math.sin((1 - porcentajeEquilibrio/100) * Math.PI) * 180}px)`,
              transform: 'translateX(10px)',
            }}
          >
            <div className="text-sm font-medium text-gray-700">Equilibrio</div>
          </div>
          
          <div 
            className="absolute pointer-events-none" 
            style={{
              left: `calc(50% + ${Math.cos(0) * 180}px)`,
              top: `calc(50% - ${Math.sin(0) * 180}px)`,
              transform: 'translateX(10px)',
            }}
          >
            <div className="text-sm font-medium text-gray-700">Meta</div>
          </div>
        </div>
        <div className="mt-2 w-full">
          <div className="flex justify-between items-center text-base">
            <div className="flex items-center">
              <span className="w-4 h-4 rounded-full bg-dashboard-danger mr-2"></span>
              <span>Punto de equilibrio: ${breakEvenPoint.toLocaleString()}</span>
            </div>
            <div className="flex items-center">
              <span className="w-4 h-4 rounded-full bg-dashboard-success mr-2"></span>
              <span>Meta: ${targetSales.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SalesGauge;
