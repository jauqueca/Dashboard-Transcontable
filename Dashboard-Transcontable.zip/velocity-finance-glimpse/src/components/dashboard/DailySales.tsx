import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Line,
  ComposedChart
} from 'recharts';

interface VentaDiaria {
  dia: number;
  ventas: number;
  tendencia?: number;
}

interface VentasDiariasProps {
  data: VentaDiaria[];
}

const DailySales: React.FC<VentasDiariasProps> = ({ data }) => {
  return (
    <div className="flex flex-col h-full">
      <h2 className="text-xl font-bold mb-2">Venta Diaria</h2>
      <div className="bg-white rounded-lg shadow-dashboard p-4 flex-grow">
        <div className="h-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart
              data={data}
              margin={{
                top: 10,
                right: 10,
                left: 10,
                bottom: 20,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis 
                dataKey="dia" 
                tickLine={false}
                axisLine={false}
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => `${value}`}
              />
              <YAxis 
                tickLine={false}
                axisLine={false}
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => `$${value/1000}k`}
              />
              <Tooltip 
                formatter={(value: number) => [`$${value.toLocaleString()}`, 'Ventas']}
                labelFormatter={(label) => `Día ${label}`}
              />
              <Bar 
                dataKey="ventas" 
                fill="#60a5fa" 
                radius={[4, 4, 0, 0]} 
                maxBarSize={50}
              />
              <Line 
                type="monotone" 
                dataKey="tendencia" 
                stroke="#2563eb" 
                strokeWidth={2} 
                dot={false} 
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default DailySales;
