import React from 'react';

interface ItemInventario {
  id: number;
  nombre: string;
  stockActual: number;
  stockMinimo: number;
  estado: 'critico' | 'alerta'; // critico es rojo, alerta es amarillo
}

interface InventarioCriticoProps {
  items: ItemInventario[];
}

const CriticalInventory: React.FC<InventarioCriticoProps> = ({ items }) => {
  return (
    <div className="flex flex-col h-full">
      <h2 className="text-xl font-bold mb-2">Inventarios Críticos</h2>
      <div className="bg-white rounded-lg shadow-dashboard p-4 flex-grow overflow-hidden">
        <div className="overflow-auto h-full">
          {items.length === 0 ? (
            <div className="h-full flex items-center justify-center text-gray-400">
              No hay inventarios críticos
            </div>
          ) : (
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2">Ítem</th>
                  <th className="text-right py-2">Stock</th>
                  <th className="text-right py-2">Mínimo</th>
                </tr>
              </thead>
              <tbody>
                {items.map((item) => (
                  <tr key={item.id} className="border-b last:border-b-0">
                    <td className="py-2">
                      <div className="flex items-center">
                        <span 
                          className={`w-3 h-3 rounded-full mr-2 ${
                            item.estado === 'critico' ? 'bg-dashboard-danger' : 'bg-dashboard-warning'
                          }`}
                        ></span>
                        <span>{item.nombre}</span>
                      </div>
                    </td>
                    <td className="text-right py-2">{item.stockActual}</td>
                    <td className="text-right py-2">{item.stockMinimo}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};

export default CriticalInventory;
