import React from 'react';
import Dashboard from '../components/dashboard/Dashboard';

const Index: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm py-4 px-6">
        <h1 className="text-2xl font-bold text-gray-800">
          TransContable - Transportes XYZ S.A.S
        </h1>
      </header>
      <main>
        <Dashboard />
      </main>
    </div>
  );
};

export default Index;
